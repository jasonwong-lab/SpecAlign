+++++++++++++++++++++++++++++++++++++++++++++++++++
ABOUT SpecAlign
+++++++++++++++++++++++++++++++++++++++++++++++++++

With the advent of clinical proteomics, a large amount of complex mass spectra are being generated. It is often of interest to find patterns hidden within such data that can be used to distinguish different sets of spectra. This is more commonly known as biomarker discovery.

SpecAlign is specifically designed for the visualization and manipulation of multiple mass spectra. The outstanding feature of SpecAlign is an algorithm for the alignment of multiple mass spectra to an average spectrum. This is particularly useful when the mass spectra are to be analyzed by methods such as machine learning, where alignment of data points for each spectrum is critical to a machine learning method's performance. Current commercial tools exist for picking and aligning peaks, however, the function for aligning the complete spectra is uncommon or non-existent. In addition to spectra alignment, SpecAlign provides many convenient tools such as zooming, cropping, smoothing, baseline subtraction, etc.

SpecAlign is also flexible and can in fact be used for visualization and manipulation of any type of spectroscopy data.

This documentation describes the functions of SpecAlign and explains how it can be used. For further details and information about SpecAlign and its algorithm has been published in:

Wong, J.W.H., Cagney, G. and Cartwright, H.M. (2005) SpecAlign � processing and alignment of mass spectra datasets. Bioinformatics, 21: 2088-2090
Wong, J.W.H., Durante, C. and Cartwright H.M. (2005) Application of Fast Fourier Transform Cross-Correlation for the Alignment of Large Chromatographic and Spectral Datasets. Anal. Chem., 77: 5655-5661
Wong, J.W.H., Jessop, D.M., Cagney, G. and Cartwright, H.M. (2006) Modeling and Resolving Overlapping Peaks for Accurate Quantitation of Mass Spectrometry Biomarker Signals, IMSC2006, Prague.


Comments are welcome, please feel free to contact 
Jason Wong <jwong@physchem.ox.ac.uk>. 

+++++++++++++++++++++++++++++++++++++++++++++++++++
REQUIREMENTS
+++++++++++++++++++++++++++++++++++++++++++++++++++

SpecAlign version 2.4 works with Windows 95 or 98, Windows ME, Windows NT 4.x, Windows 2000 or Windows XP and Windows Vista

A system with a Pentium II 300 CPU or equivalent and more than 32Mb of RAM is recommended.

SpecAlign uses Microsoft's HTML-Help system.
For the Help system to work properly, you must have Internet Explorer 5.0 or later installed.

Internet Explorer can be obtained from http://www.microsoft.com/windows/ie/default.asp

++++++++++++++++++++++++++++++++++++++++++++++++++++
KNOWN ISSUE(S)
++++++++++++++++++++++++++++++++++++++++++++++++++++

1. There appears to be a bar graph display issue with computers running Windows 9x. Other functions will work as normal.

2. The display size of SpecAlign is limited to 200 spectra. Any spectra located greater than 200 will not be drawn on screen. However, even though the spectra are not shown, they are still loaded in the program and are pre-processed as any visible spectra.

+++++++++++++++++++++++++++++++++++++++++++++++++++++
LICENSE AGREEMENT AND DISCLAIMER
+++++++++++++++++++++++++++++++++++++++++++++++++++++

This software, "SpecAlign, is protected by copyright law and international treaties and cannot be distributed, reproduced or reversed-engineered. This software is distributed 'as is' for academic and non-profit organizations. Commercial use or inclusion in another software package, in whole or in part, is prohibited unless otherwise permitted by authors of this software

This software is provided freely to the scientific community for the purpose of scientific research. There is no warranty for this software, either expressed or implied. The entire risk as to the quality and performance of this software is with the user. In no event will the authors or the University of Oxford be liable for any damages, including any general, special or consequential damages arising out of the use, misuse, or inability to use of this software.

By using the software, you acknowledge that you have read and agree to be bound by this license.

+++++++++++++++++++++++++++++++++++++++++++++++++++
CONTACT
+++++++++++++++++++++++++++++++++++++++++++++++++++

Please forward any problems or suggestions to:

Jason Wong
Physical and Theoretical Chemistry Lab,
University of Oxford, OX1 3QZ,
United Kingdom
Email: jwong@physchem.ox.ac.uk
